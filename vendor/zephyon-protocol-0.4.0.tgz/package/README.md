# Zephyon Protocol

Calm, receipt-backed payment infrastructure on Solana.

Zephyon Protocol is a Solana-native infrastructure layer focused on deterministic payment execution, treasury-controlled accounting systems, and operationally reliable blockchain payment flows.

The protocol is designed to support modern consumer-facing payment experiences through predictable infrastructure behavior, deterministic receipts, explicit governance controls, and simplified blockchain interaction patterns.

Zephyon serves as the infrastructure foundation beneath applications such as ZephiPay — a consumer-focused payment experience built on top of the protocol.

---
## Whitepaper

Read the full Zephyon Whitepaper here:

[Zephyon Whitepaper v2](./zephyon-protocol/docs/whitepaper/Zephyon_Whitepaper_v2.pdf)

# Overview

Zephyon explores how blockchain-powered payments can become more understandable, operationally practical, and approachable while preserving the speed and efficiency advantages of decentralized settlement infrastructure.

The protocol combines:

- treasury-based SPL payment infrastructure
- deterministic receipt systems
- explicit governance controls
- stress-tested accounting guarantees
- structured event observability
- frontend-integrated payment execution

The broader design philosophy centers around reducing uncertainty in blockchain payment experiences while maintaining strong operational correctness at the infrastructure layer.

---

# Core Principles

## Calm Infrastructure

Payment systems should behave predictably, fail clearly, and remain understandable under operational stress.

## Deterministic Accounting

Reliable payment infrastructure depends on explicit accounting guarantees, predictable receipt generation, and transparent transaction state management.

## Invisible Complexity

Blockchain-powered payment experiences should minimize unnecessary user-facing technical complexity wherever possible.

## Explicit Operational Control

Sensitive treasury operations and protocol-level authority boundaries are enforced directly at the infrastructure layer.

## Composable Architecture

The protocol is designed to integrate cleanly with existing Solana tooling, SPL infrastructure, and downstream applications.

---

# Current Capabilities

Zephyon Protocol currently supports:

- SPL payment execution
- deterministic receipt generation
- treasury PDA architecture
- pause/unpause governance controls
- structured event emission
- receipt-aware transaction confirmations
- frontend-integrated payment flows
- stress-tested accounting invariants
- extensive Anchor-based test coverage

The protocol is currently operating as a functional Solana devnet prototype with live payment execution and connected frontend infrastructure.

---

# Deterministic Receipt Infrastructure

A central component of Zephyon Protocol is its deterministic receipt architecture.

Payment flows generate deterministic receipt accounts designed to support:

- transaction visibility
- accounting clarity
- payment reassurance
- audit-oriented observability
- receipt-aware frontend experiences

Receipt accounts are derived predictably and can be used to support downstream indexing, analytics, transaction verification, and operational accounting systems.

---

# Governance & Safety Model

Zephyon prioritizes explicit operational guarantees and defensive infrastructure behavior.

Current safety-oriented capabilities include:

- permissioned treasury control
- protocol pause infrastructure
- deterministic PDA derivation
- authorization enforcement
- side-effect guarding during paused states
- receipt integrity validation
- negative-path testing

The protocol favors predictable and explicit failure behavior over silent or ambiguous operational outcomes.

---

# Stress Testing Framework

Zephyon includes a multi-layer adversarial stress-testing framework designed to validate accounting correctness under concurrent and chaotic operational conditions.

Current stress validation includes:

## Tier1 — Pause Flip Under Load

Verifies payment behavior during active pause-state transitions.

## Tier2 — Interleaved Chaos

Simulates concurrent payment, withdrawal, and governance operations.

## Tier3A — Multi-Recipient Storm

Validates recipient payout stability under heavy transaction volume.

## Tier3B — Deterministic Pause Windows

Applies controlled pause windows during high-volume transaction activity.

## Tier3C — Multi-Mint Isolation

Verifies accounting isolation across multiple SPL token environments.

## Tier4 — Adversarial Scheduler

Simulates unpredictable execution ordering and concurrent operational stress conditions.

---

# Accounting Invariant

Across stress scenarios, the protocol validates the invariant:

`treasury_delta == recipient_delta`

Meaning:

Value leaving the treasury must exactly equal value received by recipients.

This invariant is continuously verified through deterministic Anchor-based testing infrastructure.

---

# ZephiPay Frontend Integration

ZephiPay is the consumer-facing payment application currently integrated with Zephyon Protocol.

The frontend prototype is built with:

- Next.js
- React
- TypeScript
- Solana devnet infrastructure

The current integration demonstrates how Solana-powered payment infrastructure can support simplified consumer-facing payment experiences while keeping blockchain complexity largely beneath the interface layer.

Current frontend payment flow:

Home → Send → Confirm → Sending → Delivered → Receipt

---

# Devnet Deployment

Zephyon Protocol is currently deployed and operating on Solana devnet infrastructure.

The current deployment environment supports:

- live payment execution
- deterministic receipt generation
- frontend-integrated transaction flows
- event emission validation
- protocol testing
- payment usability experimentation

The devnet environment is actively used to validate payment flow behavior, governance controls, receipt infrastructure, and frontend integration systems.

## Runtime SDK v0.3.0 Devnet flow

The v0.3.0 SDK prepares one immutable Solana Devnet SPL Token `transferChecked` artifact without submitting it. The backend must durably persist the complete artifact, including its exact signed bytes, signature, digest, signer and blockhash metadata, authoritative transfer values, and submission/reconciliation provider identities.

Before calling Runtime submission, the backend must durably commit the execution to `SUBMISSION_COMMITTED_RECONCILE_ONLY` and attach the matching commitment. Submission then validates and sends the exact persisted bytes; it does not rebuild or mutate the transaction. After that commitment, the transaction must never be automatically submitted again. Recovery uses only its persisted signature through the independently configured reconciliation provider.

A submission kill switch should prevent the backend from initiating new submission calls, while leaving the transport and reconciliation provider available for existing executions. Reconciliation does not contact the configured submission provider. If a blockhash expires in `PREPARING` or `PREPARED_NOT_CONTACTED`, the backend may abandon that never-contacted artifact and start a fresh preparation lifecycle. Expiry after `SUBMISSION_COMMITTED_RECONCILE_ONLY` remains reconciliation-only and never authorizes regeneration or resubmission. See `docs/devnet-durable-submission-contract.md` for the complete durability contract.

---

# Whitepaper

Additional ecosystem documentation and protocol materials are available inside:

`/docs/whitepaper/`

---

# Documentation

Additional protocol documentation includes:

- `ARCHITECTURE.md`
- `GOVERNANCE.md`
- `SECURITY_MODEL.md`

---

# Developer Quickstart

## Requirements

- Rust
- Solana CLI
- Anchor Framework
- Node.js
- Yarn or pnpm

## Build

```bash
anchor build
```

## Run Tests

```bash
anchor test
```

The test suite includes deterministic stress validation and adversarial accounting verification.

---

# Roadmap Direction

Current development priorities include:

- frontend usability refinement
- receipt clarity systems
- public prototype stabilization
- infrastructure hardening
- audit-oriented preparation
- developer accessibility improvements
- documentation expansion

Longer-term development may support broader consumer-facing payment interaction systems built on top of the core infrastructure layer.

---

# Project Philosophy

Zephyon Protocol is built around the belief that blockchain-powered payment systems should become more understandable, trustworthy, and operationally practical for normal users without requiring deep technical blockchain knowledge.

The project prioritizes:

- calm infrastructure
- explicit guarantees
- usability-oriented payment design
- operational clarity
- long-term sustainability

The objective is not simply to increase blockchain activity, but to help make blockchain-powered payment infrastructure feel more approachable and usable in real-world environments.

---

# License

License information to be added.

